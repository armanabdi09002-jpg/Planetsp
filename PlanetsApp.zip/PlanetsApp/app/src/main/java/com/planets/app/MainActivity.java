package com.planets.app;

import android.app.Activity;
import android.content.ContentValues;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#05010f"));
        getWindow().setNavigationBarColor(Color.parseColor("#000000"));
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Saver(), "AndroidSaver");
        web.setWebViewClient(new WebViewClient());
        web.setDownloadListener((url, ua, cd, mime, len) -> {
            if (url.startsWith("blob:")) {
                String ext = mime != null && mime.contains("presentation") ? "pptx" : "bin";
                String name = "planets_" + System.currentTimeMillis() + "." + ext;
                web.evaluateJavascript(
                    "fetch('" + url + "').then(r=>r.blob()).then(bl=>{var fr=new FileReader();"
                    + "fr.onloadend=function(){AndroidSaver.save(fr.result.split(',')[1],'"
                    + name + "','" + mime + "');};fr.readAsDataURL(bl);});", null);
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    class Saver {
        @JavascriptInterface
        public void save(String b64, String name, String mime) {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                try (OutputStream o = getContentResolver().openOutputStream(u)) {
                    o.write(Base64.decode(b64, Base64.DEFAULT));
                }
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                    "ذخیره شد در Downloads: " + name, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                    "خطا در ذخیره فایل", Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
